import WheatherApp from './components/WeatherApp'
import './components/WeatherApp.css'

const App = () => {
  return (
    <div>
      <WheatherApp />
    </div>
  )
}

export default App